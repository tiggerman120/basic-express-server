# basic-express-server

LAB - Class 02
Project: Basic Express Server
Author: Garrett Cintron
Links and Resources
ci/cd (GitHub Actions)
back-end server url (when applicable)
front-end application (when applicable)
Setup
.env requirements (where applicable)
i.e.

PORT - 3000

How to initialize/run your application (where applicable)
node index.js

Tests
How do you run tests?
npm test
Any tests of note?
the validator tests!

UML
Link to an image of the UML for your application and response to events